var express = require('express');
var router = express.Router();

//try
var studentList = [
  {
    name: 'Stan Marsh',
    DOB: '1990-04-14',
    programme: 'BSc CS',
    level: '100',
    image: "/images/stan.png"
  },
  {
    name: 'Eric Cartman',
    DOB: '1990-04-14',
    programme: 'BSc CS',
    level: '200',
    image: "/images/eric.png"
  },
  {
    name: 'Kenny Mccormick',
    DOB: '1990-04-14',
    programme: 'BSc ICT',
    level: '100',
    image: "/images/kenny.png"
  }
];


/* GET students listing. */
router.get('/', function(req, res,) {
  res.render('students',{title: 'Students', studentList});
});
// GET student details
router.get('/:id', (req, res,) => {
  let index = req.params.id
  res.render('details', {title: "student's details", student: studentList[index]  });
 });
 
module.exports = router;
